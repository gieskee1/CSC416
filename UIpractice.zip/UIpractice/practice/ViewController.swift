//
//  ViewController.swift
//  practice
//
//  Created by Elizabeth Gieske on 10/11/16.
//  Copyright © 2016 Elizabeth Gieske. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //var color = 0
    @IBOutlet weak var Label: UILabel!
    @IBAction func Button(sender: AnyObject) {
   //     Label.text = "The label is red"
        Label.textColor = UIColor.redColor()
    
    }
    @IBAction func greenBtn(sender: AnyObject) {
   //     Label.text = "The label is green"
        Label.textColor = UIColor.greenColor()
        Label.font = UIFont.systemFontOfSize(20)
    }
    @IBOutlet weak var blueBtn: UIButton!
    @IBAction func blueButtn(sender: AnyObject) {
     //   Label.text = "The label is blue"
        Label.textColor = UIColor.blueColor()
       Label.font = UIFont(name: "Times New Roman", size: 20)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

