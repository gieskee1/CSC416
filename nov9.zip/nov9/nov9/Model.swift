//
//  Model.swift
//  nov9
//
//  Created by Elizabeth Gieske on 11/9/16.
//  Copyright © 2016 Elizabeth Gieske. All rights reserved.
//
import Foundation

class Country {
    var name: String = ""
    var capital: String = ""
    var government: String = ""
    var population: String = ""
    var flagImage: String = ""
}

class Model {
    var countries: [Country] = []
    var count: Int {
        return countries.count
    }
  /*  func loadFromPlist(plistName: String) {
        let path = NSBundle.mainBundle().pathForResource(plistName, ofType : "plist")
//        let dict = NSDictionary(contentsOfURL: path!)
        
        let countryInfo = dict!.objectForKey("countryInfo") as! Dictionary<String, Dictionary<String, String>>
        
        let countryNames = Array(countryInfo.keys).sort(<)
        for country = Country()
        country.name = CountryName*/
    func loadFromPlist(plistName: String) {
            let path = NSBundle.mainBundle().pathForResource(plistName, ofType: "plist")
            let dict = NSDictionary(contentsOfFile: path!)
            
            let countryInfo = dict!.objectForKey("countryInfo") as! Dictionary<String, Dictionary<String,String>>
            
            let countryNames = Array(countryInfo.keys).sort(<)
            for countryName in countryNames {
                let countryData = countryInfo[countryName]!
                
                let country = Country()
                country.name = countryName
                country.capital = countryData["capital"]!
                country.government = countryData["government"]!
                country.population = countryData["population"]!
                if countryData["flagImage"] != nil {
                    country.flagImage = countryData["flagImage"]!
                }
                
                countries.append(country)
            }
            
    }
    
    
    func countryByName(name: String) -> Country? {
        for country in countries{
            if country.name == name {
                return country
            }
        }
        return nil
    }
    
    func addCountry(country: Country) {
        countries.insert(country, atIndex: 0)
    }
    
    func removeCountryByName(countryName: String) {
        if let index = countries.indexOf({$0.name == countryName}) {
            countries.removeAtIndex(index)
        }
    }
    
    func moveCountryAtIndex(fromIndex: Int, toIndex: Int) {
        if fromIndex == toIndex{
            return
        }
        let movedCountry = countries[fromIndex]
        countries.removeAtIndex(fromIndex)
        countries.insert(movedCountry, atIndex: toIndex)
    }
    
}