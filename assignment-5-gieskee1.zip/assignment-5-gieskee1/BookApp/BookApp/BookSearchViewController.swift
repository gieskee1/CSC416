//
//  ViewController.swift
//  BookApp
//
//  Created by Elizabeth Gieske on 11/15/16.
//  Copyright © 2016 Elizabeth Gieske. All rights reserved.
//

import UIKit
import SwiftyJSON

class BookSearchViewController: UIViewController {
    var model = Model()
    
    @IBOutlet weak var titleText: UITextField!

    @IBOutlet weak var authorText: UITextField!
    
    @IBAction func searchBtn(sender: AnyObject) {
    }
    /*func parse(json: JSON) {
        for result in json["items"].arrayValue {
            let title = result["volumeInfo"]["title"].stringValue
            let author = result["volumeInfo"]["authors"][0].stringValue
            let publishedDate = result["volumeInfo"]["publishedDate"].stringValue
            let pageCount = result["volumeInfo"]["pageCount"].stringValue
            let averageRating = result["volumeInfo"]["averageRating"].stringValue
            let ratingsCount = result["volumeInfo"]["ratingsCount"].stringValue
            let descr = result["volumeInfo"]["description"].stringValue
            let thumbnail = result["volumeInfo"]["thumbnail"].stringValue
            print(title)
            print(author)
        }
        
    }*/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue ,sender:AnyObject?) {
        let title = titleText.text
        let author = authorText.text
        let detailsVC = segue.destinationViewController as! BookTitlesViewController
        let url = "https://www.googleapis.com/books/v1/volumes?q=" + title! + "+author:" + author!
        detailsVC.urlPath = url
    }

}

