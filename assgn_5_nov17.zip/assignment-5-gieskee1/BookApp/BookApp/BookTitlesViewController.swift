//
//  BookTitlesViewController.swift
//  BookApp
//
//  Created by Elizabeth Gieske on 11/16/16.
//  Copyright © 2016 Elizabeth Gieske. All rights reserved.
//

import UIKit

class BookTitlesViewController: UITableViewController {
    private var model = Model()
    
    var urlPath: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.useJSON(urlPath)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //print(model.count)
        return model.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("bookCell")
        let book = model.bookByIndex(indexPath.row)
      
        cell?.textLabel?.text = book.title
        cell?.detailTextLabel?.text = book.author
        return cell!
    }
    

    
    
}
