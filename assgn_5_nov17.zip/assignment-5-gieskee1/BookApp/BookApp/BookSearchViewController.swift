//
//  ViewController.swift
//  BookApp
//
//  Created by Elizabeth Gieske on 11/15/16.
//  Copyright © 2016 Elizabeth Gieske. All rights reserved.
//

import UIKit
import SwiftyJSON

class BookSearchViewController: UIViewController, UITextFieldDelegate {
    var model = Model()
    //let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(BookSearchViewController.dismissKeyboard))
    //view.addGestureRecognizer(tap)
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    @IBAction func titleTextAction(sender: AnyObject) {
    
    }
    @IBOutlet weak var titleText: UITextField!
    @IBAction func authorTextAction(sender: AnyObject) {
    }

    @IBOutlet weak var authorText: UITextField!
    
    @IBAction func searchBtn(sender: AnyObject) {
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool // called when 'return' key pressed. return false to ignore.
    {
        textField.resignFirstResponder()
        return true
    }
    /*func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }*/
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(BookSearchViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
         self.titleText.delegate = self;
         self.authorText.delegate = self;
        // Do any additional setup after loading the view, typically from a nib
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue ,sender:AnyObject?) {
        var title = titleText.text
        title = title!.stringByReplacingOccurrencesOfString(" ", withString: "")
        var author = authorText.text
        author = author!.stringByReplacingOccurrencesOfString(" ", withString: "")
        let detailsVC = segue.destinationViewController as! BookTitlesViewController
        let url = "https://www.googleapis.com/books/v1/volumes?q=" + title! + "+author:" + author!
        detailsVC.urlPath = url
    }

}

