//
//  Model.swift
//  BookApp
//
//  Created by Elizabeth Gieske on 11/15/16.
//  Copyright © 2016 Elizabeth Gieske. All rights reserved.
//

import Foundation
import SwiftyJSON

class Book {
    var title: String = ""
    var author: String = ""
    var publishedDate: String = ""
    var pageCount: Int = 0
    var averageRating: Double = 0.0
    var ratingsCount: Int = 0
    var description: String = ""
    var thumbnail: String = ""
}

class Model {
    
    var books: [Book] = []
    var count: Int {
        return books.count
    }
    func bookByIndex(i: Int) -> Book {
        return books[i]
    }
    func useJSON(urlVar: String) -> JSON {
        if let url = NSURL(string : urlVar){
            if let data = NSData(contentsOfURL: url){
                let json = JSON(data: data)
                parse(json)
                return json
            }
        }
        return nil
    }
    
    
    
    func parse(json: JSON) {
        for result in json["items"].arrayValue {
            let book = Book()
            let title = result["volumeInfo"]["title"].stringValue
            let author = result["volumeInfo"]["authors"][0].stringValue
            let publishedDate = result["volumeInfo"]["publishedDate"].stringValue
            let pageCount = result["volumeInfo"]["pageCount"].intValue
            let averageRating = result["volumeInfo"]["averageRating"].doubleValue
            let ratingsCount = result["volumeInfo"]["ratingsCount"].intValue
            let descr = result["volumeInfo"]["description"].stringValue
            let thumbnail = result["volumeInfo"]["thumbnail"].stringValue

            book.title = title
            book.author = author
            book.publishedDate = publishedDate
            book.pageCount = pageCount
            book.averageRating = averageRating
            book.ratingsCount = ratingsCount
            book.description = descr
            book.thumbnail = thumbnail
            books.append(book)
        }
        
    }


}