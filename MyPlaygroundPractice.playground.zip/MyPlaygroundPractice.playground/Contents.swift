//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


struct Resolution {
     var width = 0
    var height = 0
}

class VideoMode {
    var res = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name:String?

    
}

var someRes = Resolution()
var someVideo = VideoMode()

someRes.height = 480
someRes.width  = 640

print(someRes)

let height = someRes.height

enum myEnum {

    case A, B, C
}
enum AnotherEnum : Double{
    case A = 4.1, B = 3.0
}

let ex = AnotherEnum.A
AnotherEnum.A.rawValue

var anArray = [4,2,5,7,4]
var exam = anArray.sort{$0 < $1}
var example = anArray.filter{$0 > 4}

example
var exa = anArray.map({$0 + 1})
exa
let strArray = ["b","a", "f", "c"]
//var test = anArray.sort({(s1 : String, s2 : String) -> Bool in
//    s1.characters.count < s2.characters.count})

var testing = anArray.reduce(anArray.maxElement()!){return min($0 , $1)}
testing


















