//
//  main.swift
//  Practice
//
//  Created by Elizabeth Gieske on 10/10/16.
//  Copyright © 2016 Elizabeth Gieske. All rights reserved.
//

import UIKit

print("Hello, World!")

