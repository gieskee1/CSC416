//
//  ViewController.swift
//  CSC416Assignment4
//
//  Created by James Slone on 10/19/16.
//  Copyright © 2016 James Slone. All rights reserved.
//

import UIKit
import SwiftyJSON

struct FakeLocation {
    let latitude:Double
    let longitude:Double
    init(lat: Double, lon: Double) {
        latitude = lat
        longitude = lon
    }
}

struct arrayItem {
    let company:String
    let city:String
    let lat:Double
    let long:Double
    
    init(comp: String, cit: String, la: Double, lon: Double){
        company = comp
        city = cit
        lat = la
        long = lon
    }
}

class ViewController: UIViewController {
    
    @IBOutlet weak var elementNum: UITextField!
    @IBAction func elementNumField(sender: AnyObject) {
    }
    @IBAction func locationBtn(sender: AnyObject) {
        textView.text = "Hello World"
    }
    @IBAction func cityNameBtn(sender: AnyObject) {
        let urlVar = "https://api.citybik.es/v2/networks/"
        if let url = NSURL(string : urlVar){
            if let data = NSData(contentsOfURL: url){
                let json = JSON(data: data)
                //print(json)
                parse(json)
            }
        }
    }
    @IBAction func totalElementsBtn(sender: AnyObject) {
    }
    @IBOutlet weak var textView: UITextView!
    
    
    func parse(json: JSON) {
        print("At least I'm here")
        textView.text = "Now I'm here"
        for result in json["networks"].arrayValue {
            let compName = result["name"].stringValue
            let cityName = result["city"].stringValue
            let latValue = result["latitude"].doubleValue
            let longValue = result["longitide"].doubleValue
            let item = arrayItem(comp: compName,cit: cityName,la: latValue,lon: longValue)
           
            elements.append(item)
        }
        print(elements[11].company)
     //   let totalElem: Int? = Int(elementNum.text!)
        var i = 0
        var output = ""
        textView.text = ""
        while (i < 100){
           // var el = elements[i].company
            output = textView.text + "\n"
            textView.text = output + elements[i].company
           // textView.text = "\n"
            print(elements[i].city)
           // print("LOOP")
           // print("\n")
            i = i + 1
        }
        
        
        
        
        
        
        /* for result in json["results"].arrayValue {
            let title = result["title"].stringValue
            let body = result["body"].stringValue
            let sigs = result["signatureCount"].stringValue
            let obj = ["title": title, "body": body, "sigs": sigs]
            petitions.append(obj)
            print(petitions)
        }*/
        
       // textView.reloadData()
    }
    var user = FakeLocation(lat: 39.10138, lon: -84.51217)
    var petitions = [[String: String]]()
    var elements = [arrayItem]()
    override func viewDidLoad() {
        super.viewDidLoad()
        let urlVar = "https://api.citybik.es/v2/networks/"
        if let url = NSURL(string : urlVar){
            if let data = NSData(contentsOfURL: url){
                let json = JSON(data: data)
               // print(json)
                parse(json)
            }
        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


